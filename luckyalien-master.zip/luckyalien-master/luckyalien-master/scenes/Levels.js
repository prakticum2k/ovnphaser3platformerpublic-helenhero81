// Grassland
class Grassland extends Scene {
  // Constructor
  constructor() {
    // Super
    super("Grassland");
  }
}

// Forest
class Forest extends Scene {
  // Constructor
  constructor() {
    // Super
    super("Forest");
  }
}

// Clouds
class Clouds extends Scene {
  // Constructor
  constructor() {
    // Super
    super("Clouds");
  }
}

// Boss
class Boss extends Scene {
  // Constructor
  constructor() {
    // Super
    super("Boss");
  }
}
