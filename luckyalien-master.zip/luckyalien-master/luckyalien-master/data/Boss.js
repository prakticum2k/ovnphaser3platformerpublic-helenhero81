world["Boss"] = {
  length: 1300,
  height: 643,
  hasClouds: false,
  backgroundImage: "background2",
  blocks: [
    [1280, 623, "grassBlock"],
    [1240, 623, "grassBlock"],
    [1280, 583, "grassBlock"],
    [1240, 583, "grassBlock"],
    [20, 623, "grassBlock"],
    [60, 623, "grassBlock"],
    [20, 583, "grassBlock"],
    [60, 583, "grassBlock"],
  ],
  mushrooms: [
  ],
  boxes: [
  ],
  spiders: [
  ],
  springs: [
  ],
  spikes: [
  ],
  snails: [
  ],
  lasers: [
  ],
  flags: [
  ],
  doors: [
  ],
  signs: [
  ],
  bats: [
  ]
};
